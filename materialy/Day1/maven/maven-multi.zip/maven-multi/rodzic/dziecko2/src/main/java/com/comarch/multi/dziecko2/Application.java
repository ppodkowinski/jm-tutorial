package com.comarch.multi.dziecko2;

import java.util.Date;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.comarch.multi.dziecko1.DateUtilityClass;

public class Application {

    //**********************************************************************************************
    // CLASS
    //**********************************************************************************************
    static private final Logger logger = Logger.getLogger(Application.class);

    //----------------------------------------------------------------------------------------------
    static public void main(String[] args) {
        PropertyConfigurator.configure(Application.class.getClassLoader().getResource("log4j.properties"));

        Application application = new Application();
        application.doSomething();
    }

    //**********************************************************************************************
    // INSTANCE
    //**********************************************************************************************

    //----------------------------------------------------------------------------------------------
    Application() {
        logger.info("Initialized Application");
    }

    //----------------------------------------------------------------------------------------------
    private void doSomething() {
        System.out.println("Hello, World!");
        System.out.println("It's " + DateUtilityClass.formatDate(new Date()));
    }
}
