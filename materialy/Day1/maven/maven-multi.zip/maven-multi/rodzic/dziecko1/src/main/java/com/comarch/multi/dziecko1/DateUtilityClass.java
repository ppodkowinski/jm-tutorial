package com.comarch.multi.dziecko1;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;


public class DateUtilityClass {

    //**********************************************************************************************
    // CLASS
    //**********************************************************************************************

    //----------------------------------------------------------------------------------------------
    static public String formatDate(Date date) {
        Locale locale = new Locale("pl", "PL");
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM, locale);

        return dateFormat.format(date);
    }

    //**********************************************************************************************
    // INSTANCE
    //**********************************************************************************************
}
