package com.comarch.multi.dziecko1;

import java.util.Date;

import org.junit.Test;
import org.junit.Assert;

import pl.lodz.p.kis.multi.dziecko1.DateUtilityClass;

public class DateFormatterTest {

    //**********************************************************************************************
    // CLASS
    //**********************************************************************************************

    //**********************************************************************************************
    // INSTANCE
    //**********************************************************************************************

    //----------------------------------------------------------------------------------------------
    @Test
    public void testFormattingDate() {
        long time = 1294944398263l;
        Date date = new Date(time);

        String formatedDate = DateUtilityClass.formatDate(date);
        Assert.assertEquals("2011-01-13 19:46:38", formatedDate);
    }
}
